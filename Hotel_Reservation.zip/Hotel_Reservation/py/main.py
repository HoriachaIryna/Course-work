import sys
import ctypes
from PySide6.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton, QVBoxLayout, QWidget, QMessageBox, QDialog, QLineEdit, QComboBox

#Під'єднання коду С++
hotel_reservation = ctypes.CDLL('./main.so')

#Під'єднання всіх функцій С++ коду та їх аргументів
hotel_reservation.book.restype = ctypes.c_bool
hotel_reservation.book.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
hotel_reservation.set_rooms_availability.argtypes = []
hotel_reservation.booked_rooms_availability.argtypes = [ctypes.c_char_p, ctypes.c_size_t]
hotel_reservation.free_rooms_availability.argtypes = [ctypes.c_char_p, ctypes.c_size_t]

#Створення головного вікна інтерфейсу
class MainWindow(QMainWindow):
  def __init__(self):
      super().__init__()
      self.setWindowTitle("Hotel Reservation")
      self.setGeometry(100, 100, 300, 200) #Зазначення розмірів вікна


      layout = QVBoxLayout()
      self.book_button = QPushButton("Book Room") #Створення кнопки бронювання
      self.book_button.clicked.connect(self.book_room) #Під'єднання до функції бронювання з С++
      layout.addWidget(self.book_button)

      self.show_button = QPushButton("Show Booked Rooms") #Створення кнопки заброньованих кімнат
      self.show_button.clicked.connect(self.show_booked_rooms) #Під'єднання до функції з С++
      layout.addWidget(self.show_button)

      self.name_button = QPushButton("Name")
      self.name_button.setStyleSheet("background-color: purple")
      self.name_button.clicked.connect(self.show_name)

      layout.addWidget(self.name_button)


      central_widget = QWidget()
      central_widget.setLayout(layout)
      self.setCentralWidget(central_widget)


  def show_name(self):
      QMessageBox.information(self, "Name", "Iryna Horiacha")

  #Функція бронювання
  def book_room(self):
      #Під'єднання до вікна бронювання
      dialog = BookRoomDialog(self)
      if dialog.exec():
          #Витяг інформації бронювання з вікна
          room_type = dialog.get_room_type().encode()
          num_people = dialog.get_num_people()
          num_days = dialog.get_num_days()
          guest_name = dialog.get_guest_name().encode()
          passport_id = dialog.get_passport_id()


          #Перевірка резервації
          if hotel_reservation.book(room_type, num_people, guest_name, passport_id, num_days):
              QMessageBox.information(self, "Reservation", "Successful reservation!")
          else:
              QMessageBox.warning(self, "Reservation", "This room is not available.")


  def show_booked_rooms(self):
      dialog = ShowBookedRoomsDialog(self) #Виклик функції С++
      dialog.exec()


#Створення вікна для бронювання
class BookRoomDialog(QDialog):
  def __init__(self, parent=None):
      super().__init__(parent)
      self.setWindowTitle("Book Room")
      self.setGeometry(100, 100, 300, 200)
      layout = QVBoxLayout()


      #Створення списку для вибору типу кімнати
      self.room_type_label = QLabel("Room Type:")
      self.room_type_combobox = QComboBox()
      self.room_type_combobox.addItem("Standard")
      self.room_type_combobox.addItem("Bedroom")
      self.room_type_combobox.addItem("Balcony")
      self.room_type_combobox.addItem("President")
      layout.addWidget(self.room_type_label)
      layout.addWidget(self.room_type_combobox)


      #Створення списку для вибору кількості спальних місць у номері
      self.num_people_label = QLabel("Number of People:")
      self.num_people_combobox = QComboBox()
      self.num_people_combobox.addItem("1")
      self.num_people_combobox.addItem("2")
      self.num_people_combobox.addItem("3")
      self.num_people_combobox.addItem("4")
      layout.addWidget(self.num_people_label)
      layout.addWidget(self.num_people_combobox)


      #Поле для вводу кількості днів перебування
      self.num_days_label = QLabel("Number of Days:")
      self.num_days_lineedit = QLineEdit()
      layout.addWidget(self.num_days_label)
      layout.addWidget(self.num_days_lineedit)

      # Поле для вводу імені гостя
      self.guest_name_label = QLabel("Guest's Name:")
      self.guest_name_lineedit = QLineEdit()
      layout.addWidget(self.guest_name_label)
      layout.addWidget(self.guest_name_lineedit)

      # Поле для вводу ідентифікаційного коду гостя
      self.passport_id_label = QLabel("Passport ID:")
      self.passport_id_lineedit = QLineEdit()
      layout.addWidget(self.passport_id_label)
      layout.addWidget(self.passport_id_lineedit)

      # Кнопка підтвердження бронювання
      self.book_button = QPushButton("Book")
      self.book_button.clicked.connect(self.accept)
      layout.addWidget(self.book_button)
      self.setLayout(layout)


  #Функції для отримання значень після введення
  def get_room_type(self):
      return self.room_type_combobox.currentText()

  def get_num_people(self):
      return int(self.num_people_combobox.currentText())

  def get_num_days(self):
      return int(self.num_days_lineedit.text())

  def get_guest_name(self):
      return self.guest_name_lineedit.text()

  def get_passport_id(self):
      return int(self.passport_id_lineedit.text())


#Створення вікна для відображення заброньованих номерів
class ShowBookedRoomsDialog(QDialog):
  def __init__(self, parent=None):
      super().__init__(parent)
      self.setWindowTitle("Booked Rooms")
      self.setGeometry(100, 100, 400, 300)
      layout = QVBoxLayout()


      self.booked_rooms_label = QLabel("Booked Rooms:")
      layout.addWidget(self.booked_rooms_label)
      self.booked_rooms_text = QLabel()
      layout.addWidget(self.booked_rooms_text)


      #Кнопка для оновлення поточної інформації
      self.refresh_button = QPushButton("Refresh")
      self.refresh_button.clicked.connect(self.refresh_booked_rooms)
      layout.addWidget(self.refresh_button)
      self.setLayout(layout)


  #Функція оновлення поточних даних
  def refresh_booked_rooms(self):
      buffer_size = 4096
      buffer = ctypes.create_string_buffer(buffer_size)

      # Виклик функції наявних номерів з бібліотеки коду С++
      hotel_reservation.booked_rooms_availability(buffer, buffer_size)
      self.booked_rooms_text.setText(buffer.value.decode())


if __name__ == "__main__":
  hotel_reservation.set_rooms_availability()
  app = QApplication(sys.argv)
  window = MainWindow()
  window.show()

  sys.exit(app.exec())
