#include <stdio.h>
#include <iostream>
#include <string.h>
#include <sstream>
#include <iomanip>
using namespace std;


typedef struct rooms_availability{
    int number;
    string type;
    string status;
}ROOMS;

ROOMS rooms[21];

class Guest {
private:
    string name;
    int id_code;
    
public:
    Guest() {
        name = "Unknown";
        id_code = 0;
    }
    
    string GetName(){
        return name;
    }
    
    int GetID(){
        return id_code;
    }
    
    void Set(string name, int id_code){
        this->name = name;
        this->id_code = id_code;
    }
    
    ~Guest() {}
};

class Room {
protected:
    int number;
    int days;
    string type;
    int price;
    int total_price;
    Guest guest;
    
public:
    Room() {
        number = 0;
        days = 0;
        price = 0;
        total_price = 0;
        type = "None";
        guest = Guest();
    }
    
    Room(int number, int days) {
        this->number = number;
        this->days = days;
        guest = Guest();
        
    }
    
    void SetGuest(string name, int id){
        guest.Set(name, id);
    }
    
    string GetName(){
        return guest.GetName();
    }
    
    int GetID(){
        return guest.GetID();
    }
    
    void SetDays(int days) {
        this->days = days;
        this->total_price = price * this->days;
    }
    
    int GetNumber(){
        return number;
    }
    
    int GetPrice(){
        return price;
    }
    
    int GetTotalPrice(){
        return total_price;
    }
    
    int GetDays() {
        return days;
    }
    
    string GetType() {
        return type;
    }
    
    ~Room() {}
};


class Standard : public Room {
private:
    int SetPrice() {
        int price = 100;
        return price;
    }
    
public:
    Standard() {
        price = SetPrice();
        type = "Standard";
    }
    
    Standard(int number, int days) : Room(number, days){
        price = SetPrice();
        total_price = price*days;
        type = "Standard";
    }
    
    ~Standard() {}
};

class Bedroom : public Room {
private:
    int SetPrice() {
        int price = 200;
        return price;
    }
    
public:
    Bedroom() {
        price = SetPrice();
        type = "Bedroom";
    }
    
    Bedroom(int number, int days) : Room(number, days){
        price = SetPrice();
        total_price = price*days;
        type = "Bedroom";
    }
    
    ~Bedroom() {}
};

class Balcony : public Room {
private:
    int SetPrice() {
        int price = 250;
        return price;
    }
    
public:
    Balcony() {
        price = SetPrice();
        type = "Balcony";
    }
    
    Balcony(int number, int days) : Room(number, days){
        price = SetPrice();
        total_price = price*days;
        type = "Balcony";
    }
    
    ~Balcony() {}
};

class President : public Room {
private:
    int SetPrice() {
        int price = 500;
        return price;
    }
    
public:
    President() {
        price = SetPrice();
        type = "President";
    }
    
    President(int number, int days) : Room(number, days){
        price = SetPrice();
        total_price = price*days;
        type = "President";
    }
    
    ~President() {}
};




extern "C"{
Room *booked_rooms[21];
int booked_index = 0;
bool book(char type[], int number, char name[], int id, int days);
void set_rooms_availability();
void booked_rooms_availability(char* buffer, int buffer_size);
void free_rooms_availability(char* buffer, int buffer_size);
}


extern "C"{

bool book(char type[], int number, char name[], int id, int days) {
    if (strcmp(type, "Standard") == 0) {
        for (int i = 0; i < 10; i++) {
            if (rooms[i].number == number && rooms[i].status == "free") {
                rooms[i].status = "booked";
                cout << "Successful reservation!" << endl;
                Standard *room = new Standard(number, days);
                room->SetGuest(name, id);
                booked_rooms[booked_index++] = room;
                return true;
            }
        }
    }
    else if (strcmp(type, "Bedroom") == 0) {
        for (int i = 10; i < 15; i++) {
            if (rooms[i].number == number && rooms[i].status == "free") {
                rooms[i].status = "booked";
                cout << "Successful reservation!" << endl;
                Bedroom *room = new Bedroom(number, days);
                room->SetGuest(name, id);
                booked_rooms[booked_index++] = room;
                return true;
            }
        }
    }
    else if (strcmp(type, "Balcony") == 0) {
        for (int i = 15; i < 19; i++) {
            if (rooms[i].number == number && rooms[i].status == "free") {
                rooms[i].status = "booked";
                cout << "Successful reservation!" << endl;
                Balcony *room = new Balcony(number, days);
                room->SetGuest(name, id);
                booked_rooms[booked_index++] = room;
                return true;
            }
        }
    }
    else if (strcmp(type, "President") == 0) {
        for (int i = 19; i < 21; i++) {
            if (rooms[i].number == number && rooms[i].status == "free") {
                rooms[i].status = "booked";
                cout << "Successful reservation!" << endl;
                President *room = new President(number, days);
                room->SetGuest(name, id);
                booked_rooms[booked_index++] = room;
                return true;
            }
        }
    }
    
    cout << "This room is not available." << endl;
    return false;
}

void set_rooms_availability(){
    int i;
    for (i = 0; i < 10; i++) {
        if(i<4) rooms[i].number = 1;
        if(i>=4 && i<6) rooms[i].number = 2;
        if(i>=6 && i<8) rooms[i].number = 3;
        if(i>=8) rooms[i].number = 4;
        
        rooms[i].type = "Standard";
        rooms[i].status = "free";
    }
    
    for (; i < 15; i++) {
        if(i<13) rooms[i].number = 2;
        else rooms[i].number = 4;
        
        rooms[i].type = "Bedroom";
        rooms[i].status = "free";
    }
    
    for (; i < 19; i++) {
        if(i<17) rooms[i].number = 2;
        else rooms[i].number = 3;
        rooms[i].type = "Balcony";
        rooms[i].status = "free";
    }
    
    for (; i < 21; i++) {
        if(i==19) rooms[i].number = 2;
        else rooms[i].number = 4;
        rooms[i].type = "President";
        rooms[i].status = "free";
    }
    
}

void booked_rooms_availability(char* buffer, int buffer_size){
    int i = 0;
    string info;
    while (i<booked_index){
        info += "Name: " + booked_rooms[i]->GetName() + "\n";
        info += "Passport ID: " + to_string(booked_rooms[i]->GetID()) + "\n";
        info += booked_rooms[i]->GetType() + " for " + to_string(booked_rooms[i]->GetNumber()) + "\n";
        info += "Days: " + to_string(booked_rooms[i]->GetDays()) + "\n";
        info += "Price per day: " + to_string(booked_rooms[i]->GetPrice()) + "\n";
        info += "Price: " + to_string(booked_rooms[i++]->GetTotalPrice()) + "\n\n";
    }
    
    strncpy(buffer, info.c_str(), buffer_size - 1);
    buffer[buffer_size - 1] = '\0';
}

void free_rooms_availability(char* buffer, int buffer_size){
    string info;
    int i = 0;
    while(i < 21){
        if(rooms[i].status == "free"){
            info += rooms[i].type + " for " + to_string(rooms[i].number) + "\n\n";
        }
    }
    strncpy(buffer, info.c_str(), buffer_size - 1);
    buffer[buffer_size - 1] = '\0';
}

}

